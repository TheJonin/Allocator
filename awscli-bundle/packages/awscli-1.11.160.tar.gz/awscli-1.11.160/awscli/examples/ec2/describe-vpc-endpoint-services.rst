**To describe VPC endpoint services**

This example describes all available endpoint services for the region.

Command::

  aws ec2 describe-vpc-endpoint-services

Output::

  {
    "ServiceNames": [
        "com.amazonaws.us-east-1.dynamodb", 
        "com.amazonaws.us-east-1.s3"
    ]
  }